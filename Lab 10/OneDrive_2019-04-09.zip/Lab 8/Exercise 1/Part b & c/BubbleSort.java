public class BubbleSort <T extends Number>{

    /**
     * @param args the command line arguments
     */
	
	private T arr[];

	   public void add(T t[]) {
	      this.arr = t;
	   }

	   public T[] get() {
	      return arr;
	   }

	public  void bubbleSort() {
        for (int i = 0; i < arr.length - 1; i++) {
            for (int j = 0; j < arr.length - i - 1; j++) {
            	if(arr[j].doubleValue() > arr[j + 1].doubleValue()){
            		T temp = arr[j];
            		arr[j] = arr[j + 1];
            		arr[j + 1] = temp;
            		
            	}
            	
            }
        }
    }
    
	public  void printArray() {
        for (int i = 0; i < 10; i++) {
            System.out.print(arr[i] + "  ");
        }
        System.out.println();
    }
    
    
}
