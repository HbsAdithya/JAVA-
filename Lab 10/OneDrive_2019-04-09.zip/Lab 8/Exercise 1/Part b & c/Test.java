public class Test {

    public static void main(String[] args) {
        // TODO code application logic here
        Integer arry1[] = {45, 3, 78, 12, 54, 72, 56, 89, 13, 44};
        Double arry2[] = {38.0, 3.0, 83.0, 12.0, 54.0, 72.0, 56.0, 89.0, 13.0, 44.0};
        
        BubbleSort<Integer> ob1 = new BubbleSort<Integer>();
        ob1.add(arry1);
        ob1.bubbleSort();
        ob1.printArray();
        
        BubbleSort<Double> ob2 = new BubbleSort<Double>();
        ob2.add(arry2);
        ob2.bubbleSort();
        ob2.printArray();
    }
}

