
public class Exercise2 {
	public static void main(String[] args){
		print("Name is", "Kamal");
		print("Age is", 24);		
		print("Salary is", 245123.15);
		
	}
	
	public static <T> void print(String msg, T val) {
        System.out.println(msg +" "+ val);
    }
    

}
