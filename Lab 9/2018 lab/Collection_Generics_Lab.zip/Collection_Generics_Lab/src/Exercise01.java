import java.util.SortedSet;
import java.util.TreeSet;

public class Exercise01 {

	public static void main(String[] args) {
		
			showTreeSet();

	}
	
	public static void showTreeSet(){
		
		SortedSet<Integer> set = new TreeSet<Integer>();
		set.add(10);
		set.add(20);
		set.add(50);
		set.add(50);
		set.add(20);
		set.add(10);
		set.add(30);
		set.add(40);
		set.add(60);
		set.add(10);
		
		for (Integer value : set) {
			System.out.println(value);
		}	
	}
}
