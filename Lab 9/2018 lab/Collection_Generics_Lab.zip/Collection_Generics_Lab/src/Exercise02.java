import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class Exercise02 {

	public static void main(String[] args) {
     
	    Integer [] array = new Integer[]{90, 10, 30, 70, 20, 100, 40, 50, 60, 80};
		
		List<Integer> arrayList =  Arrays.asList(array);
		System.out.println("Original Array =>" + arrayList);
		
		Collections.sort(arrayList);	
		System.out.println("Sorted Array =>"+ arrayList);
		
		Collections.reverse(arrayList);	
		System.out.println("Reverse => " + arrayList);

	}

}
