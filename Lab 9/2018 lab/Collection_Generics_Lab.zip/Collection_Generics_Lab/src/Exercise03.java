import java.util.LinkedHashMap;
import java.util.Map;

public class Exercise03 {
	
	public static void printMap(Map<String, LinkedHashMap<String, Double>> expensesMap){
		
		for (Map.Entry<String, LinkedHashMap<String, Double>> expenses : expensesMap.entrySet()) {
			System.out.println(expenses.getKey());
			for (Map.Entry<String, Double> expense : expenses.getValue().entrySet()) {
				System.out.println(expense.getKey() + ", " + expense.getValue());
			}
		}
	}
	
	public static void main(String[] args) {
		
		printMap(Expenses.getConstructionExpenses());
	}
}
