import java.util.LinkedHashMap;
import java.util.Map;

public class Exercise04 {
	
	public static void printExpensesMap(Map<String, LinkedHashMap<String, Double>> expensesMap){
		
		double total = 0.0;
		
		for (Map.Entry<String, LinkedHashMap<String, Double>> expenses : expensesMap.entrySet()) {
			System.out.println(expenses.getKey());
			for (Map.Entry<String, Double> expense : expenses.getValue().entrySet()) {
				total += expense.getValue();
				System.out.println(expense.getKey() + ", " + expense.getValue());
			}
		}
		System.out.println("Total Construction expenses = " + total);
	}
	
	public static void main(String[] args) {
		
		printExpensesMap(Expenses.getConstructionExpenses());
	}

}
