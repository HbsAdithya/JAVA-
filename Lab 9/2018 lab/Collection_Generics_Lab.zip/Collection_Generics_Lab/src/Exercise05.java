import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

public class Exercise05 {
	
	public static <K,V> void genericMapDisplay(Map<K, LinkedHashMap<K, V>> subjectsMap){
		
		for (Map.Entry<K, LinkedHashMap<K, V>> subjects : subjectsMap.entrySet()) {
			System.out.println(subjects.getKey());
			for (Map.Entry<K, V> student : subjects.getValue().entrySet()) {
				System.out.println(student.getKey() + ", " + student.getValue());
			}
		}
	}
	

	public static void main(String[] args) {
		
		genericMapDisplay(Expenses.getConstructionExpenses());
		genericMapDisplay(Subjects.getStudentMarks());
	}

}
