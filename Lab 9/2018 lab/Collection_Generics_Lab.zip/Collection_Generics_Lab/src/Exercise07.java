import java.util.LinkedHashMap;
import java.util.Map;

class GenericMap<K, V> {
	
	public static <K,V> void genericMapDisplay(Map<K, LinkedHashMap<K, V>> subjectsMap){
		
		for (Map.Entry<K, LinkedHashMap<K, V>> subjects : subjectsMap.entrySet()) {
			System.out.println(subjects.getKey());
			for (Map.Entry<K, V> student : subjects.getValue().entrySet()) {
				System.out.println(student.getKey() + ", " + student.getValue());
			}
		}
	}
}

public class Exercise07 {
	
	public static void main(String[] args) {
		
		GenericMap<String, LinkedHashMap<String, Double>> expenses = new GenericMap<>();
		expenses.genericMapDisplay(Expenses.getConstructionExpenses());
		
		GenericMap<String, LinkedHashMap<String, Integer>> subjects = new GenericMap<>();
		subjects.genericMapDisplay(Subjects.getStudentMarks());
	}

}
