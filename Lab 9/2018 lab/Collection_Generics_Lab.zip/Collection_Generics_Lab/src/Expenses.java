import java.util.LinkedHashMap;
import java.util.Map;

public class Expenses {
	
	public static Map<String, LinkedHashMap<String, Double>> getConstructionExpenses(){
		
		LinkedHashMap<String, Double> materialExpensesMap = new LinkedHashMap<String, Double>();
		materialExpensesMap.put("Sand 1mt", 15000.0);
		materialExpensesMap.put("Cement 1mt", 18000.0);
		materialExpensesMap.put("Stones 1mt", 12000.0);
		materialExpensesMap.put("Iron bars 10kg", 20000.0);
		
		LinkedHashMap<String, Double> workerExpensesMap = new LinkedHashMap<String, Double>();
		workerExpensesMap.put("Architect salary", 180000.0);
		workerExpensesMap.put("Electrician salary", 80000.0);
		workerExpensesMap.put("Head Bass salary", 65000.0);
		workerExpensesMap.put("Helper salary", 25000.0);
		
		LinkedHashMap<String, Double> furnitureExpenses = new LinkedHashMap<String, Double>();
		furnitureExpenses.put("Sofa", 120000.0);
		furnitureExpenses.put("Ceiling", 250000.0);
		furnitureExpenses.put("Beds", 100000.0);
		furnitureExpenses.put("Tables", 80000.0);
		furnitureExpenses.put("Chairs", 90000.0);
		
		Map<String, LinkedHashMap<String, Double>> constructionExpenses = 
				new LinkedHashMap<String, LinkedHashMap<String, Double>>();
		constructionExpenses.put("Material", materialExpensesMap);
		constructionExpenses.put("Workers", workerExpensesMap);
		constructionExpenses.put("Furniture", furnitureExpenses);
		
		return constructionExpenses;
	}
}
