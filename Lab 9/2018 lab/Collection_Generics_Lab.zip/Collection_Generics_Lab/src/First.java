import java.util.ArrayList;
import java.util.List;

public class First {

	public static void main(String[] args) {

		//listTotal(addElements());
		listGenericTotal(addElementGenericArray());

	}

	/**
	 * Without generic
	 * 
	 * @return
	 */
	public static List addElements() {

		List list = new ArrayList();
		list.add(10);
		list.add(20);
		list.add(30);
		list.add(40);
		list.add("abc");
		return list;
	}

	/**
	 * Calculate Total
	 * 
	 * @param list
	 */
	public static void listTotal(List list) {

		int total = 0;
		for (Object object : list) {

			total += (Integer) object;
		}
		System.out.println("Total is = " + total);
	}

	/**
	 * ArrayList with Generics
	 * @return
	 */
	public static List<Integer> addElementGenericArray() {

		List<Integer> list = new ArrayList<Integer>();
		list.add(10);
		list.add(20);
		list.add(30);
		list.add(40);
		return list;
	}

	/**
	 * 
	 * @param list
	 */
	public static void listGenericTotal(List<Integer> list) {

		int total = 0;
		for (Integer vlue : list) {

			total += vlue;
		}
		System.out.println("Total is = " + total);
	}
}
