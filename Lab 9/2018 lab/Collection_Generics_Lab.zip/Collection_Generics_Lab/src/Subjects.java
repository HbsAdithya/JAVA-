import java.util.LinkedHashMap;
import java.util.Map;

public class Subjects {

	public static Map<String, LinkedHashMap<String, Integer>> getStudentMarks() {

		LinkedHashMap<String, Integer> oopMarksMap = new LinkedHashMap<String, Integer>();
		oopMarksMap.put("IT1011233", 80);
		oopMarksMap.put("IT1011244", 85);
		oopMarksMap.put("IT1011255", 75);
		oopMarksMap.put("IT1011266", 65);
		oopMarksMap.put("IT1011277", 55);

		LinkedHashMap<String, Integer> seMarksMap = new LinkedHashMap<String, Integer>();
		seMarksMap.put("IT1011233", 80);
		seMarksMap.put("IT1011244", 85);
		seMarksMap.put("IT1011255", 75);
		seMarksMap.put("IT1011266", 65);
		seMarksMap.put("IT1011277", 55);

		LinkedHashMap<String, Integer> dbmsMarksMap = new LinkedHashMap<String, Integer>();
		dbmsMarksMap.put("IT1011233", 80);
		dbmsMarksMap.put("IT1011244", 85);
		dbmsMarksMap.put("IT1011255", 75);
		dbmsMarksMap.put("IT1011266", 65);
		dbmsMarksMap.put("IT1011277", 55);

		Map<String, LinkedHashMap<String, Integer>> subjectsMap = 
				new LinkedHashMap<String, LinkedHashMap<String, Integer>>();
		subjectsMap.put("OOP", oopMarksMap);
		subjectsMap.put("SE", seMarksMap);
		subjectsMap.put("DBMS", dbmsMarksMap);

		return subjectsMap;
	}
}
