package Ex1;

public interface IPrint {
	void printLine();
	void printDetails();
}
